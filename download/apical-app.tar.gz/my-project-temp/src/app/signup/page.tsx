'use client'

import * as React from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { signIn } from 'next-auth/react'
import { ArrowRight, Loader2, Mail, CheckCircle2 } from 'lucide-react'

import { ApicalMark } from '@/components/apical/logo'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useToast } from '@/hooks/use-toast'

const BENEFITS = [
  'Free to start — no credit card required',
  'Bring your own models or use the built-in gateway',
  'Connects to your local machine via the desktop runtime',
]

export default function SignupPage() {
  const router = useRouter()
  const { toast } = useToast()

  const [name, setName] = React.useState('')
  const [email, setEmail] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [loading, setLoading] = React.useState(false)
  const [googleLoading, setGoogleLoading] = React.useState(false)

  const passwordStrong = password.length >= 8

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !password || !name) return
    if (!passwordStrong) {
      toast({
        title: 'Password too short',
        description: 'Use at least 8 characters.',
        variant: 'destructive',
      })
      return
    }
    setLoading(true)
    try {
      // 1. Create the account via the public registration route.
      const regRes = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, name }),
      })
      if (!regRes.ok) {
        const err = await regRes.json().catch(() => ({}))
        throw new Error(err.error || 'Registration failed')
      }

      // 2. Sign in via NextAuth credentials provider.
      const res = await signIn('credentials', {
        redirect: false,
        email,
        password,
      })
      if (!res || res.error) {
        throw new Error(res?.error || 'Account created, but sign in failed. Try logging in.')
      }

      toast({
        title: 'Account created',
        description: `Welcome to Apical, ${name.split(' ')[0]}!`,
      })
      router.push('/')
      router.refresh()
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Sign up failed'
      toast({ title: 'Sign up failed', description: msg, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const continueWithGoogle = async () => {
    setGoogleLoading(true)
    try {
      await signIn('google', { callbackUrl: '/' })
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Google sign in failed'
      toast({ title: 'Google sign in failed', description: msg, variant: 'destructive' })
      setGoogleLoading(false)
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center bg-gradient-to-b from-primary/5 via-background to-background px-4 py-12">
      <div
        aria-hidden
        className="pointer-events-none absolute -top-32 left-1/2 h-72 w-[36rem] -translate-x-1/2 rounded-full bg-primary/15 blur-3xl"
      />
      <div className="relative grid w-full max-w-4xl gap-8 md:grid-cols-2 md:items-center">
        {/* Marketing column (hidden on mobile) */}
        <div className="hidden md:block">
          <div className="mb-6 flex items-center gap-2">
            <ApicalMark className="h-7 w-7" withGlow />
            <Link href="/" className="text-lg font-semibold tracking-tight">
              Apical<span className="text-primary">.</span>
            </Link>
          </div>
          <h1 className="text-3xl font-semibold leading-tight tracking-tight">
            Tell Apical what needs doing. <span className="text-primary">Consider it done.</span>
          </h1>
          <p className="mt-3 text-sm text-muted-foreground">
            Apical agents plan, execute, and report back. You decide. It does.
          </p>
          <ul className="mt-6 space-y-2.5">
            {BENEFITS.map((b) => (
              <li key={b} className="flex items-start gap-2 text-sm">
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <span>{b}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Form column */}
        <div className="md:hidden mb-6 flex items-center justify-center gap-2">
          <ApicalMark className="h-7 w-7" withGlow />
          <Link href="/" className="text-lg font-semibold tracking-tight">
            Apical<span className="text-primary">.</span>
          </Link>
        </div>

        <Card className="border-border/60 shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl">Create your account</CardTitle>
            <CardDescription>
              Free to start. No credit card. Runs on your computer.
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-4">
            <Button
              type="button"
              variant="outline"
              className="w-full"
              onClick={continueWithGoogle}
              disabled={googleLoading || loading}
            >
              {googleLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <GoogleIcon className="h-4 w-4" />
              )}
              Continue with Google
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-[10px] uppercase tracking-wider">
                <span className="bg-card px-2 text-muted-foreground">or</span>
              </div>
            </div>

            <form onSubmit={submit} className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="signup-name" className="text-xs">
                  Name
                </Label>
                <Input
                  id="signup-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Jordan Doe"
                  autoComplete="name"
                  required
                  autoFocus
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="signup-email" className="text-xs">
                  Email
                </Label>
                <Input
                  id="signup-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  autoComplete="email"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="signup-password" className="text-xs">
                  Password
                </Label>
                <Input
                  id="signup-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 8 characters"
                  autoComplete="new-password"
                  required
                />
                {password && !passwordStrong && (
                  <p className="text-[11px] text-muted-foreground">
                    Use at least 8 characters.
                  </p>
                )}
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <>
                    Create account
                    <ArrowRight className="ml-1.5 h-4 w-4" />
                  </>
                )}
              </Button>
            </form>
          </CardContent>

          <CardFooter className="justify-center">
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Mail className="h-3 w-3" />
              Already have an account?
              <Link
                href="/login"
                className="font-medium text-primary hover:underline"
              >
                Sign in
              </Link>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z"
      />
    </svg>
  )
}
